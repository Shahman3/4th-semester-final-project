<?php

  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "contact-us-game";
  
  $conn = mysqli_connect($servername,$username,$password,$dbname);

  // $sql ="INSERT INTO people(name,email,message) value($servername,$username,$password,$dbname)";
  //  mysqli_query($conn,$sql);
   
   
   if($conn){
    //  echo "connection ok";
    }
    else{
      echo'connection Failed'.mysqli_connect_error();
    }
    error_reporting(0);


?>



<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link
      rel="stylesheet"
      href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css"
      integrity="sha384-WskhaSGFgHYWDcbwN70/dfYBj47jz9qbsMId/iRN3ewGhXQFZCSftd1LZCfmhktB"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="main.css" />

    <!-- <link rel="stylesheet" href="css/bootstrap.css" /> -->
  </head>
  <body data-spy="scroll" data-target="#main-nav" id="home">
    <nav
      class="navbar navbar-expand-md bg-white navbar-light fixed-top"
      id="main-nav"
    >
      <div class="container">
        <a href="#" class="navbar-brand text-black">😺PlayFire</a>
        <button
          class="navbar-toggler"
          data-toggle="collapse"
          data-target="#mynav"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="mynav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item d-none d-md-block">
              <a href="#home" class="nav-link">Home</a>
            </li>
            <li class="nav-item">
              <a href="#games" class="nav-link">Games</a>
            </li>
            <li class="nav-item">
              <a href="#about-head-section" class="nav-link">About</a>
            </li>

            <li class="nav-item">
              <a href="#main-footer" class="nav-link">
                <!-- data-toggle="modal"
                data-target="#contactModal" -->
                Contact
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- HOME  -->

    <section id="home">
      <div
        id="myCarousel"
        class="carousel slide d-none d-md-block"
        data-ride="carousel"
      >
        <ol class="carousel-indicators">
          <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
          <li data-target="#myCarousel" data-slide-to="1"></li>
          <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
          <div class="carousel-item carousel-image- active">
            <img src="img/slide/s1.jpg" class="d-block h-img w-100" alt="..." />
            <div class="container">
              <div class="carousel-caption d-none d-md-block mb-5">
                <!-- <h1 class="display-3">Heading One</h1>
                <p class="lead">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste,
                  aperiam vel ullam deleniti reiciendis ratione quod aliquid
                  inventore vero perspiciatis.
                </p> -->
                <a href="#" class="btn btn-primary btn-lg">Play Now</a>
              </div>
            </div>
          </div>

          <div class="carousel-item carousel-image-">
            <img src="img/slide/s5.jpg" class="d-block h-img w-100" alt="..." />
            <div class="container">
              <div class="carousel-caption d-none d-md-block mb-5">
                <!-- <h1 class="display-3">Heading Two</h1>
                <p class="lead">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste,
                  aperiam vel ullam deleniti reiciendis ratione quod aliquid
                  inventore vero perspiciatis.
                </p> -->
                <a href="#" class="btn btn-secondary btn-lg">Play Now</a>
              </div>
            </div>
          </div>

          <div class="carousel-item carousel-image-">
            <img src="img/slide/s2.jpg" class="d-block h-img w-100" alt="..." />
            <div class="container">
              <div class="carousel-caption d-none d-md-block mb-5">
                <!-- <h1 class="display-3">Heading Three</h1>
                <p class="lead">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste,
                  aperiam vel ullam deleniti reiciendis ratione quod aliquid
                  inventore vero perspiciatis.
                </p> -->
                <a href="#" class="btn btn-danger btn-lg">Play Now</a>
              </div>
            </div>
          </div>
        </div>

        <a href="#myCarousel" data-slide="prev" class="carousel-control-prev">
          <span class="carousel-control-prev-icon"></span>
        </a>

        <a href="#myCarousel" data-slide="next" class="carousel-control-next">
          <span class="carousel-control-next-icon"></span>
        </a>
      </div>
    </section>

    <!-- /************************************/ -->
    <!-- /* GAMES section */ -->
    <!-- /************************************/ -->
    <section class="container games" id="games">
      <!-- <div class="row"><h2 class="heading">Our Games</h2></div>  -->
      <div class="row">
        <div class="col-md-3 col-sm-6 mb-4 mb-md-0">
          <div class="imagepig">
            <a class="child" href="pig/index.html">
              <img
                src="img/o0.png"
                class="w-100 shadow-1-strong   child"
                alt="game photo "
            /></a>
            <!-- <div class="content"><h1>Coming Soon</h1></div> -->
          </div>

          <div class="image">
            <img
              src="img/o1.png"
              class="w-100 shadow-1-strong  "
              alt="game photo"
            />
            <div class="content"><h1>Coming Soon</h1></div>
          </div>
        </div>

        <div class="col-md-3 col-sm-6 mb-4 mb-md-0">
          <div class="image">
            <img
              src="img/o4.png"
              class="w-100 shadow-1-strong "
              alt="game photo "
            />
            <div class="content"><h1>Coming Soon</h1></div>
          </div>
          <div class="image">
            <img
              src="img/o2.png"
              class="w-100 shadow-1-strong  "
              alt="game photo"
            />
            <div class="content"><h1>Coming Soon</h1></div>
          </div>
        </div>

        <div class="col-md-3 col-sm-6 mb-4 mb-md-0">
          <div class="image">
            <img
              src="img/o11.png"
              class="w-100 shadow-1-strong "
              alt="game photo"
            />
            <div class="content"><h1>Coming Soon</h1></div>
          </div>
          <div class="image">
            <img
              src="img/o3.jpg"
              class="w-100 shadow-1-strong "
              alt="game photo"
            />
            <div class="content"><h1>Coming Soon</h1></div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6 mb-4 mb-md-0">
          <div class="image">
            <img
              src="img/o13.png"
              class="w-100 shadow-1-strong "
              alt="game photo"
            />
            <div class="content"><h1>Coming Soon</h1></div>
          </div>
          <div class="image">
            <img
              src="img/o14.png"
              class="w-100 shadow-1-strong "
              alt="game photo"
            />
            <div class="content"><h1>Coming Soon</h1></div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-3 col-sm-6 mb-4 mb-md-0">
          <div class="image">
            <img
              src="img/o15.png"
              class="w-100 shadow-1-strong "
              alt="game photo "
            />
            <div class="content"><h1>Coming Soon</h1></div>
          </div>
          <div class="image">
            <img
              src="img/o16.jpg"
              class="w-100 shadow-1-strong "
              alt="game photo "
            />
            <div class="content"><h1>Coming Soon</h1></div>
          </div>
        </div>
        <div class="col-md-3 col-sm-6 mb-4 mb-md-0">
          <div class="image">
            <img
              src="img/o10.png"
              class="w-100 shadow-1-strong "
              alt="game photo "
            />
            <div class="content"><h1>Coming Soon</h1></div>
          </div>
          <div class="image">
            <img
              src="img/o7.webp"
              class="w-100 shadow-1-strong "
              alt="game photo "
            />
            <div class="content"><h1>Coming Soon</h1></div>
          </div>
        </div>

        <div class="col-md-3 col-sm-6 mb-4 mb-md-0">
          <div class="image">
            <img
              src="img/o9.png"
              class="w-100 shadow-1-strong "
              alt="game photo "
            />
            <div class="content"><h1>Coming Soon</h1></div>
          </div>
          <div class="image">
            <img
              src="img/o5.png"
              class="w-100 shadow-1-strong "
              alt="game photo"
            />
            <div class="content"><h1>Coming Soon</h1></div>
          </div>
        </div>

        <div class="col-md-3 col-sm-6 mb-4 mb-md-0">
          <div class="image">
            <img
              src="img/o8.png"
              class="w-100 shadow-1-strong "
              alt="game photo"
            />
            <div class="content"><h1>Coming Soon</h1></div>
          </div>
          <div class="image">
            <img
              src="img/o12.png"
              class="w-100 shadow-1-strong "
              alt="game photo"
            />
            <div class="content"><h1>Coming Soon</h1></div>
          </div>
        </div>
      </div>
      <!-- SMALL BOX GAMEs -->
      <div class="row">
        <div class="col-md-2 col-sm-4 col-6 mb-4 mb-md-0">
          <div class="image">
            <a class="child" href="pig/index.html">
              <img
                src="img/min/p0.png"
                class="w-100 shadow-1-strong child"
                alt="game photo"
            /></a>
            <div class="content"><h6>Coming Soon</h6></div>
          </div>

          <div class="image">
            <img
              src="img/min/p1.png"
              class="w-100 shadow-1-strong "
              alt="game photo "
            />
            <div class="content"><h6>Coming Soon</h6></div>
          </div>
        </div>
        <div class="col-md-2 col-sm-4 col-6 mb-4 mb-md-0">
          <div class="image">
            <a class="child" href="pig/index.html">
              <img
                src="img/min/p2.png"
                class="w-100 shadow-1-strong child"
                alt="game photo "
            /></a>
            <div class="content"><h6>Coming Soon</h6></div>
          </div>

          <div class="image">
            <img
              src="img/min/p3.png"
              class="w-100 shadow-1-strong "
              alt="game photo"
            />
            <div class="content"><h6>Coming Soon</h6></div>
          </div>
        </div>
        <div class="col-md-2 col-sm-4 col-6 mb-4 mb-md-0">
          <div class="image">
            <a class="child" href="pig/index.html">
              <img
                src="img/min/p4.png"
                class="w-100 shadow-1-strong  child"
                alt="game photo "
            /></a>
            <div class="content"><h6>Coming Soon</h6></div>
          </div>

          <div class="image">
            <img
              src="img/min/p5.jpeg"
              class="w-100 shadow-1-strong "
              alt="game photo "
            />
            <div class="content"><h6>Coming Soon</h6></div>
          </div>
        </div>

        <div class="col-md-2 col-sm-4 col-6 mb-4 mb-md-0">
          <div class="image">
            <img
              src="img/min/p6.png"
              class="w-100 shadow-1-strong "
              alt="game photo"
            />
            <div class="content"><h6>Coming Soon</h6></div>
          </div>
          <div class="image">
            <img
              src="img/min/p7.png"
              class="w-100 shadow-1-strong "
              alt="game photo"
            />
            <div class="content"><h6>Coming Soon</h6></div>
          </div>
        </div>

        <div class="col-md-2 col-sm-4 col-6 mb-4 mb-md-0">
          <div class="image">
            <img
              src="img/min/p8.png"
              class="w-100 shadow-1-strong "
              alt="game photo"
            />
            <div class="content"><h6>Coming Soon</h6></div>
          </div>
          <div class="image">
            <img
              src="img/min/p9.png"
              class="w-100 shadow-1-strong "
              alt="game photo"
            />
            <div class="content"><h6>Coming Soon</h6></div>
          </div>
        </div>
        <div class="col-md-2 col-sm-4 col-6 mb-4 mb-md-0">
          <div class="image">
            <img
              src="img/min/p10.png"
              class="w-100 shadow-1-strong "
              alt="game photo"
            />
            <div class="content"><h6>Coming Soon</h6></div>
          </div>
          <div class="image">
            <img
              src="img/min/p11.jpg"
              class="w-100 shadow-1-strong "
              alt="game photo"
            />
            <div class="content"><h6>Coming Soon</h6></div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-2 col-sm-4 col-6 mb-4 mb-md-0">
          <div class="image">
            <a class="child" href="pig/index.html">
              <img
                src="img/min/p12.jpg"
                class="w-100 shadow-1-strong  child"
                alt="game photo"
            /></a>
            <div class="content"><h6>Coming Soon</h6></div>
          </div>

          <div class="image">
            <img
              src="img/min/p13.png"
              class="w-100 shadow-1-strong "
              alt="game photo"
            />
            <div class="content"><h6>Coming Soon</h6></div>
          </div>
        </div>
        <div class="col-md-2 col-sm-4 col-6 mb-4 mb-md-0">
          <div class="image">
            <a class="child" href="pig/index.html">
              <img
                src="img/min/p14.png"
                class="w-100 shadow-1-strong  child"
                alt="game photo"
            /></a>
            <div class="content"><h6>Coming Soon</h6></div>
          </div>

          <div class="image">
            <img
              src="img/min/p15.png"
              class="w-100 shadow-1-strong "
              alt="game photo"
            />
            <div class="content"><h6>Coming Soon</h6></div>
          </div>
        </div>
        <div class="col-md-2 col-sm-4 col-6 mb-4 mb-md-0">
          <div class="image">
            <a class="child" href="pig/index.html">
              <img
                src="img/min/p16.png"
                class="w-100 shadow-1-strong  child"
                alt="game photo"
            /></a>
            <div class="content"><h6>Coming Soon</h6></div>
          </div>

          <div class="image">
            <img
              src="img/min/p17.png"
              class="w-100 shadow-1-strong "
              alt="game photo"
            />
            <div class="content"><h6>Coming Soon</h6></div>
          </div>
        </div>

        <div class="col-md-2 col-sm-4 col-6 mb-4 mb-md-0">
          <div class="image">
            <img
              src="img/min/p18.png"
              class="w-100 shadow-1-strong "
              alt="game photo"
            />
            <div class="content"><h6>Coming Soon</h6></div>
          </div>
          <div class="image">
            <img
              src="img/min/p19.png"
              class="w-100 shadow-1-strong "
              alt="game photo"
            />
            <div class="content"><h6>Coming Soon</h6></div>
          </div>
        </div>

        <div class="col-md-2 col-sm-4 col-6 mb-4 mb-md-0">
          <div class="image">
            <img
              src="img/min/p20.jpeg"
              class="w-100 shadow-1-strong "
              alt="game photo"
              
            />
            <div class="content"><h6>Coming Soon</h6></div>
          </div>
          <div class="image">
            <img
              src="img/min/p21.png"
              class="w-100 shadow-1-strong "
              alt="game photo"

            />
            <div class="content"><h6>Coming Soon</h6></div>
          </div>
        </div>
        <div class="col-md-2 col-sm-4 col-6 mb-4 mb-md-0">
          <div class="image">
            <img
              src="img/min/p22.png"
              class="w-100 shadow-1-strong "
              alt="game photo"
              
            />
            <div class="content"><h6>Coming Soon</h6></div>
          </div>
          <div class="image">
            <img
              src="img/min/p23.jpeg"
              class="w-100 shadow-1-strong "
              alt="game photo"
            />
            <div class="content"><h6>Coming Soon</h6></div>
          </div>
        </div>
     
      </div>
    </section>
     <!-- HI -->
     <!-- <div class="cotainer"> 
     <div class="row ml-5">
        <div class="col-md-3 ml-5 mb-4 mb-md-0">
         

          <div class="image">
            <img
              src="img/o1.png"
              class="w-100 shadow-1-strong rounded "
              alt=""
            />
            <div class="content"><h1>Coming Soon</h1></div>
          </div>
        </div>

       
      </div> </div> -->
      <!-- HI -->
    <!-- /************************************/ -->
    <!-- /* ABOUT section */ -->
    <!-- /************************************/ -->
    <section id="about-head-section">
      <div class="container bg-white">
        <div class="row">
          <dl class="">
            <dd class="about-header">About PlayFire</dd>
            <dt class="dt1">Online Games on PlayFire</dt>
            <dd>Hi, gamers! Wellcome to PlayFire!</dd>
            <dd>
              PlayFire has the best free online games that you can play alone or
              with friends. Our games are playable on desktop,tablets and mobile
              so you can enjoy them at home or on the road.There's something
              here for players of all ages so, no matter how old you are, you'll
              find something fun to play!
            </dd>
            <dt class="dt">
              NO Downloads,No Subscriptions - Just Click And Play!
            </dt>
            <dd>
              We offer instant play to all our games without downloads, login,
              ads or other distractions. All you need to do is just click on a
              game to begin playing it! Start with game created by us:<a
                href="pig/index.html"
                >Pig Game</a
              >
            </dd>
            <dt class="dt">What is PlayFire</dt>
            <dd>
              PlayFire is based in Faisalabad and has a team of 2 people working
              on our gaming platform. Our goal is to create the ultimate onlines
              playground. Free and open to all.
            </dd>
          </dl>
        </div>
      </div>
    </section>
    


    <!-- /************************************/ -->
    <!-- /* FOOTER section */ -->
    <!-- /************************************/ -->
    <section>
      <footer id="main-footer" class="bg-light">
        <div class="container">
          <div class="row">
            <div class="col text-center py-4">
              <h3>😺PlayFire</h3>
              <p>Copyright &copy; 2023</p>
          <button class="btn btn-info" data-toggle="modal" data-target="#contactModal">Contact Us</button>
            
            </div>
          </div>
        </div>
      </footer>
    </section>
 <!-- CONTACT MODAL -->
 <div class="modal fade text-dark" id="contactModal">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Contact Us</h5>
          <button class="close" data-dismiss="modal">
            <span>&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form action="index.php" method="POST">
            <div class="form-group">
              <label for="name">Name</label>
              <input type="text" name='name' class="form-control" required />
            </div>
            <div class="form-group">
              <label for="email">Email</label>
              <input type="email" name='email' class="form-control" required>
            </div>
            <div class="form-group">
              <label for="message">Message</label>
              <input type='text' name='message' class="form-control" required />
            </div>
            <input type='submit' name='submit' value='Submit' class="btn btn-primary w-100  "/>
          </form>
        </div>
        
      </div>
    </div>
  </div>

    
    <script
      src="http://code.jquery.com/jquery-3.3.1.min.js"
      integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"
      integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"
      integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
      crossorigin="anonymous"
    ></script>

    <script>
      $("body").scrollspy({ target: "#main-nav" });

      // Smooth Scrolling
      $("#main-nav a").on("click", function (event) {
        if (this.hash !== "") {
          event.preventDefault();

          const hash = this.hash;

          $("html, body").animate(
            {
              scrollTop: $(hash).offset().top,
            },
            800,
            function () {
              window.location.hash = hash;
            }
          );
        }
      });
    </script>
  </body>
</html>
<?php

 if(isset($_POST["submit"])){
   $fln=$_POST['name'];
   $fem=$_POST['email']; 
   $fmes=$_POST['message']; 


   $query="INSERT INTO contact  values ('$fln','$fem','$fmes')";
  $data= mysqli_query($conn,$query) ;
}
 //if($data){
  // echo "inserted";
 //}else{
  //echo "failed inserted";

 //}
 mysqli_close($conn);
?>